frametimer = 0

Buttons = {}
table.insert(Buttons, Button)

function OnHit(Button)
    TotalDef = Player.def + Player.armordef
    Player.Hurt(9999999999999999999999999)
end

function CreateButton(x, y, create)
    local Button = CreateProjectile("LikeButton", x, y)
    table.insert(Buttons, Button)
end


function Update()
    if frametimer % 60 == 0 then
        NumberToRemove = math.random(7) - 1
        for i = 0, 6, 1
        do
            if i ~= NumberToRemove then 
                local XPos = 180
                local YPos = (0-Arena.height/2) + Arena.height/6 * i
                CreateButton(XPos, YPos)
            end
        end
    end
    for i = #Buttons, 1, -1
    do
            Buttons[i].move(-2.2, 0)
    end
    frametimer = frametimer + 1
end
