frametimer = 0

Buttons = {}
table.insert(Buttons, Button)

function OnHit(Button)
    TotalDef = Player.def + Player.armordef
    Player.Hurt(125 - TotalDef)
end

function CreateButton(x, y, create)
    local Button = CreateProjectile("SubscribeButton", x, y)
    table.insert(Buttons, Button)
end


function Update()
    if frametimer % 120 == 0 then
        
            local XPos = 0
            local YPos = Arena.height/2
            CreateButton(XPos, YPos)
    end
    for i = #Buttons, 1, -1
    do
        CButton = Buttons[i]
        if frametimer < 119 then
            CButton.move(0, -1)
        elseif frametimer == 120 then 
            CButton.remove()
            table.remove(Buttons, i)
        elseif frametimer < 239 then 
            CButton.move(0, -1)
        elseif frametimer == 240 then
            
        elseif frametimer < 359 then 
            CButton.move(0, -1)
        else 
            CButton.remove()
            table.remove(Buttons, i)
        end

    end
    frametimer = frametimer + 1
end