frametimer = 0
Buttons = {}

function OnHit(Button)
    Player.hurt(99999999999999999)
end

function CreateButton(x, y, create)
    local Button = CreateProjectile("CommentButton", x, y)
    table.insert(Buttons, Button)
end

function Update()
    if frametimer == 0 then --0
        PosX = Player.x
        PosY = Player.y
    elseif frametimer == 60 then --1
        CreateButton(PosX, PosY)
        PosX = Player.x
        PosY = Player.y
    elseif frametimer == 120 then --2
        CreateButton(PosX, PosY)
        PosX = Player.x
        PosY = Player.y
    elseif frametimer == 180 then --3
        CreateButton(PosX, PosY)
        PosX = Player.x
        PosY = Player.y
    elseif frametimer == 240 then --4
        CreateButton(PosX, PosY)
        PosX = Player.x
        PosY = Player.y
    elseif frametimer == 300 then --5
        CreateButton(PosX, PosY)
        PosX = Player.x
        PosY = Player.y
    elseif frametimer == 360 then --6
        CreateButton(PosX, PosY)
        PosX = Player.x
        PosY = Player.y
    end
    frametimer = frametimer + 1
end