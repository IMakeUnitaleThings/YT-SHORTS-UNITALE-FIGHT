Player.name = "Youtube"

comments = {"You should subscribe to IMakeUnitaleThings"}
commands = {"SUBSCRIBE"}
randomdialogue = {"SUBSCRIBE"}

sprite = "shorts_logo" --Always PNG. Extension is added automatically.
name = "SHORT"
hp = 1
atk = 10000
def = 1
check = "YT SHORT"
dialogbubble = "rightlarge"-- See documentation for what bubbles you have available.
canspare = false 
cancheck = true

function HandleAttack(attackstatus)
    if attackstatus == -1 then
        -- player pressed fight but didn't press Z afterwards
    else
        -- player did actually attack
    end
end

function HandleCustomCommand(command)
    if command == "SUBSCIBE" then
        currentdialogue = {"SUBSCRIBE"}
        BattleDialog("SUBSCRIBE")
    end
end