encountertext = "THIS FIGHT IS DESIGNED FOR A VIDEO. THIS FIGHT IS NOT DESIGNED TO BE FUN TO PLAY, SO IF THAT'S WHAT YOU WANT PLAY SOMETHING DIFFERENT" 
wavetimer = 6.0
arenasize = {90, 160}
SetPPCollision(true)

revive = true 

autolinebreak = true
enemies = {
"SHORT"
}

enemypositions = {
    {0, 0}
    }

    possible_attacks = {"Like", "Comment", "Subscribe"}
    
    function EncounterStarting()
        -- If you want to change the game state immediately, this is the place.
    end
    
    function EnemyDialogueStarting()
        -- Good location for setting monster dialogue depending on how the battle is going.
    end
    
    function EnemyDialogueEnding()
        -- Good location to fill the 'nextwaves' table with the attacks you want to have simultaneously.
        nextwaves = { possible_attacks[math.random(#possible_attacks)] }
    end
    
    function DefenseEnding() --This built-in function fires after the defense round ends.
        encountertext = RandomEncounterText() --This built-in function gets a random encounter text from a random enemy.
    end
    
    function HandleSpare()
        State("ENEMYDIALOGUE")
    end
    
    function HandleItem(ItemID)
        BattleDialog({"Selected item " .. ItemID .. "."})
    end

